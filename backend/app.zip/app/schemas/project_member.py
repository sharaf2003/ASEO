"""
ASEO Generated Module

Project Member schemas.
"""


from datetime import datetime

from enum import Enum

from pydantic import BaseModel





# ==========================
# Project Member Roles
# ==========================


class ProjectMemberRole(str, Enum):

    MEMBER = "MEMBER"

    DEVELOPER = "DEVELOPER"





# ==========================
# Create Project Member
# ==========================


class ProjectMemberCreate(BaseModel):

    user_id: int

    role: ProjectMemberRole = ProjectMemberRole.MEMBER





# ==========================
# Update Project Member Role
# ==========================


class ProjectMemberUpdate(BaseModel):

    role: ProjectMemberRole





# ==========================
# Project Member Response
# ==========================


class ProjectMemberResponse(BaseModel):

    id: int

    project_id: int

    user_id: int

    role: str

    created_at: datetime



    class Config:

        from_attributes = True