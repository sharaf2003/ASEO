from datetime import datetime

from sqlalchemy import (
    String,
    Text,
    DateTime
)

from sqlalchemy.orm import (
    Mapped,
    mapped_column
)

from sqlalchemy.sql import func

from app.database.base import Base





class Project(Base):
    """
    Project database model.

    Represents generated ASEO projects.
    """


    __tablename__ = "projects"



    id: Mapped[int] = mapped_column(

        primary_key=True,

        index=True

    )



    name: Mapped[str] = mapped_column(

        String(200),

        nullable=False,

        index=True

    )



    description: Mapped[str | None] = mapped_column(

        Text,

        nullable=True

    )



    status: Mapped[str] = mapped_column(

        String(50),

        nullable=False,

        default="created",

        index=True

    )



    created_at: Mapped[datetime] = mapped_column(

        DateTime(timezone=True),

        server_default=func.now()

    )



    updated_at: Mapped[datetime] = mapped_column(

        DateTime(timezone=True),

        server_default=func.now(),

        onupdate=func.now()

    )