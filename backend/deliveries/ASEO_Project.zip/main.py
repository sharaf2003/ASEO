from fastapi import FastAPI

from app.api import projects





app = FastAPI(

    title="ASEO Platform",

    description="""
    Autonomous Software Engineering Organization.

    AI powered software engineering platform
    for autonomous project generation,
    analysis and deployment.
    """,

    version="11.0.0"

)





# ==========================
# Register API Routers
# ==========================


app.include_router(

    projects.router,

    prefix="/api/projects",

    tags=["Projects"]

)





# ==========================
# Startup Event
# ==========================


@app.on_event("startup")
def startup_event():

    print(
        "ASEO Platform Started Successfully"
    )





# ==========================
# Health Check
# ==========================


@app.get(

    "/health",

    tags=["System"]

)
def health_check():

    return {

        "system":

            "ASEO",


        "status":

            "running",


        "version":

            "11.0.0",


        "architecture":

            "Layered Architecture",


        "database":

            "connected"

    }





# ==========================
# System Information Endpoint
# ==========================


@app.get(

    "/info",

    tags=["System"]

)
def system_info():

    return {

        "message":

            "Welcome to ASEO Platform",


        "docs":

            "/docs",


        "health":

            "/health"

    }