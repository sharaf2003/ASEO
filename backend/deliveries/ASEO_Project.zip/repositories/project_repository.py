from sqlalchemy.orm import Session

from app.models.project import Project



class ProjectRepository:
    """
    Handles database operations
    related to projects.
    """



    def create(
        self,
        db: Session,
        project: Project
    ):

        db.add(project)

        db.commit()

        db.refresh(project)

        return project





    def get_all(
        self,
        db: Session
    ):

        return db.query(Project).all()